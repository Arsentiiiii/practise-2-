public class testauthor
{
    public static void main(String[] args)
    {
        author a1 = new author ("Misha", "qwerty@mail.ru" ,'m');
        author a2 = new author ("Van Darkholme" , "slave@gmail.com" , 'u');
        author a3 = new author ("Jotaro","jojo@mail.ru",'m');
        author a4 = new author ("Daria" , "Daria2001@mail.ru",'f');
        System.out.println(a1.toString());
        System.out.println(a2.toString());
        System.out.println(a3.toString());
        System.out.println(a4.toString());


    }
}
