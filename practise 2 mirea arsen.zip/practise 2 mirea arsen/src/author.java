import java.lang.*;

public class author
{
    private String name;
    private String email;
    private char gender;

    public author(String n , String e , char g)
    {
        this.name = n;
        this.email = e;
        if (g=='m')
        {
            this.gender = g;
        }
            else if (g=='f')
            {
                this.gender = g;
            }
            else
        {
            this.gender = 'u';
        }
    }
    public String getName()
    {
        return name;
    }
    public String getEmail()
    {
        return email;
    }

    public void setEmail(String email)
    {
        this.email = email;
    }

    public char getGender()
    {
        return gender;
    }


    @Override
        public String toString()
    {
        return name +" ("+gender+") at "+email;
    }
}
























